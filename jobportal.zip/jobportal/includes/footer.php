<!--footer-->

<footer id="footer" class="jumbotron" style="margin-top:15%; background-color:#04488a;">
        <p class="pull-right"><a class="btn" href="#">Back to top</a></p>
        <p>&copy; 2020 JobsFinder &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')         </script> 
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.js"></script>
</body>
</html>